#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <unistd.h>
#include <fstream>
#include <bitset>
#include <windows.h>
#include <iomanip>
#define HLT 0x8000
#define MI 0x4000
#define RI 0x2000
#define RO 0x1000
#define IO 0x0800
#define II 0x0400
#define AI 0x0200
#define AO 0x0100
#define SUMO 0x0080
#define SU 0x0040
#define BI 0x0020
#define OI 0x0010
#define CE 0x0008
#define CO 0x0004
#define J 0x0002
#define FI 0x0001
//

void ClearScreen()
  {
  HANDLE                     hStdOut;
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  DWORD                      count;
  DWORD                      cellCount;
  COORD                      homeCoords = { 0, 0 };

  hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );
  if (hStdOut == INVALID_HANDLE_VALUE) return;

  /* Get the number of cells in the current buffer */
  if (!GetConsoleScreenBufferInfo( hStdOut, &csbi )) return;
  cellCount = csbi.dwSize.X *csbi.dwSize.Y;

  /* Fill the entire buffer with spaces */
  /*
  if (!FillConsoleOutputCharacter(
    hStdOut,
    (TCHAR) ' ',
    cellCount,
    homeCoords,
    &count
    )) return;
*/
  /* Fill the entire buffer with the current colors and attributes */
  /*
  if (!FillConsoleOutputAttribute(
    hStdOut,
    csbi.wAttributes,
    cellCount,
    homeCoords,
    &count
    )) return;
*/
  /* Move the cursor home */
  SetConsoleCursorPosition( hStdOut, homeCoords );
  }
void ShowConsoleCursor(bool showFlag)
{
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO     cursorInfo;

    GetConsoleCursorInfo(out, &cursorInfo);
    cursorInfo.bVisible = showFlag; // set the cursor visibility
    SetConsoleCursorInfo(out, &cursorInfo);
}
//

/*TODO::
-control word parser
-flags register

*/



bool running = true;
int bus = 0; //bus bits
bool ext_input = false;
bool reset = false;
bool jumpzero = false;
bool jumpcarry = false;


class register_module {
public:
    //int tristate = 0; //this state will be 0 for unconnected, 1 for input, 2 for output
    int data = 0b00000000; //this is the current data stored in the register
    void output() {
        //std::cout <<"reg output: "<< data << std::endl;
        bus = data;
    }
    void input(){
       data = bus;
       //std::cout <<"reg input: "<< data <<std::endl;
    }   
    int datadump(){
        return data;
    }
   // int state(){
   //     return tristate;
   // }
    void clear(){
        data = 0b00000000;
    }
};//register

class arithmetic_logic_unit{
public:
    int tristate = 0;   //this should only ever be 0 or 2, disconnect or output
    int data = 0b00000000;
    bool is_subtract = false; //switch between adding and subtracting
    int datadump(register_module reg1, register_module reg2){
        if(!is_subtract)
            return reg1.data + reg2.data;
        else
            return reg1.data - reg2.data;
        
    }   
    int state(){
        return tristate;
    }
    void output(register_module register1, register_module register2){
        if(!is_subtract){
            data = register1.data +register2.data;
        }else{
            data = (int)register1.data - (int)register2.data;
            is_subtract = false;
        }
        bus = data;
    }
    void subtract(){
        is_subtract = true;
    }
    void add(){
        is_subtract = false;
    }
    void clear(){
        data = 0b00000000;
    }
    bool jump_zero(register_module regA, register_module regB){
        if(regA.data + regB.data == 0){
            jumpzero = true;
            return true;
        }else{
            jumpzero = false;
            return false;
        }
    }
    bool jump_carry(register_module regA, register_module regB){
        if(regA.data + regB.data > 256){
            jumpcarry = true;
            return true;
        }else{
            jumpcarry = false;
            return false;
        }
    }
};//arithmetic logic unit

class output_module{
public:
    int tristate = 0;
    bool signed_2 = false;//if it's showing signed 2s complement, ie with negatives
    int data = 0b00000000;
    int displayed_value = 0;
    void input(){
        data = bus;
        if(!signed_2){
            displayed_value = (int)data; 
        }else{
            displayed_value = (int)data;
            //TODO: CHANGE THIS SO THAT IT ACTUALLY DEALS WITH SIGNED 2S
        }
        //std::cout << std::endl;
        //std::cout << "Output: " << displayed_value;
        //std::cout << std::endl;
    }
    void output(){
        bus = data;
    }
    void display(){
        
    }
};//output module

class clock_module{
public:
    float clock_period = 100000;
    bool step = false;
    bool halt = false;
    int count = 0;
    clock_module(int period){
        clock_period = period;
    }
    void clock_update(){
        count ++;
        if(halt){
            while(!reset);
        }
        else if(step){
            while(!ext_input);
        }else{
            //std::cout<<"Sleeping"<<std::endl;
            usleep(clock_period);
        }
    }

};//clock module

class memory_module{
public:
    //char chosen_data = 0b00000000;//the data that will be output
    int memory_address = 0;
    int ram [16] = {
       0b00011110,          //location 0000
       0b00101111,          //location 0001
       0b11100000,          //location 0010
       0b11110000,          //location 0011
       0b00000000,          //location 0100
       0b00000000,          //location 0101
       0b00000000,          //location 0110
       0b00000000,          //location 0111
       0b00000000,          //location 1000
       0b00000000,          //location 1001
       0b00000000,          //location 1010
       0b00000000,          //location 1011
       0b00000000,          //location 1100
       0b00000000,          //location 1101
       0b00000001,          //location 1110
       0b00000010,          //location 1111
    };
    void input(){//write
        //std::cout <<"ram input"<<std::endl;
        ram[memory_address] = bus;
    }
    void output(){//read
        //std::cout <<"ram output: "<< ram[memory_address] << std::endl;
        bus = ram[memory_address];
    }
    void memory_input(){
        //std::cout <<"memory input: "<< bus << std::endl;
        memory_address = (bus&0x0F);// should only get the bottom 4 bits
    }

};//memory module

class counter{
public:
    int current_count = 0;
    int mod =0;
    counter(int mod_value){
        mod = mod_value;
    }
    void increment(){
        if(mod != 0)
            current_count = (current_count + 1) % mod;
        else
            current_count ++;        

    }
    void output(){
        bus = current_count;
    }
    void input(){
        current_count = bus;
    }
    void clear(){
        current_count = 0;
    }

};//counter

class control_module{
public:
/* 
    Values corresponding to each component of the control word:
    1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16
    HLT MI  RI  RO  IO  II  AI  AO  ΣO  SU  BI  OI  CE  CO  J   FI
*/
    unsigned short control_word = 0x0000;
    //int input_value = 0b00000000;
    int instruction =0;
    int instr_counter;
    /*counter my_counter;
    register_module my_register;
    control_module(counter A, register_module B){
        my_counter = A;
        my_register = B;
    };*/
    void input(register_module my_register, counter my_counter){
        instruction = (my_register.data >>4);  
        instr_counter = (my_counter.current_count);
        //std::cout<<"instruction register data:"<< instruction << ". instruction counter:" << (int)instr_counter <<std::endl;
    }
    unsigned short control_word_update(){
    /* This will parse through in two parts, 
    first if the instr_coutner is less than 2, 
    then through the instruction and through instr_counter
    */
        //std::cout<<"Control word update"<<std::endl;
        control_word = 0;
        if(instr_counter == 0b0000){                    //FETCH step 1
            control_word = 0x4004;                      //MI, CO

        }else if(instr_counter == 0b0001){              //FETCH step 2
            control_word = 0x1408;                      //RO, II, CE
        }else{
        //std::cout<<"switch cases"<<std::endl;
        switch(instruction){
            case 0b0000:                                //----------NOP----------
                control_word = 0x0000;                  //doesn't do anything, all zeros
            break;
            case 0b0001:                                //----------LDA----------
                if(instr_counter == 0b0010)
                    control_word = 0x4800;              //MI, IO
                else if(instr_counter == 0b0011)
                    control_word = 0x1200;              //RO, AI
                else
                    control_word = 0x0000;              //no other steps
                
            break;
            case 0b0010:                                //----------ADD----------
                if(instr_counter == 0b0010)
                    control_word = 0x4800;              //MI IO
                else if(instr_counter == 0b0011)
                    control_word = 0x1020;              //RO BI
                else if(instr_counter == 0b0100)
                    control_word = 0x0280;              //AI ΣO
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b0011:                                //----------SUB----------
                if(instr_counter == 0b0010)
                    control_word = 0x4800;              //MI IO
                else if(instr_counter == 0b0011)
                    control_word = 0x1020;              //RO BI
                else if(instr_counter == 0b0100)
                    control_word = 0x02C0;              //AI ΣO SU
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b0100:                                //----------STA----------
                if(instr_counter == 0b0010)
                    control_word = 0x4800;              //MI IO
                else if(instr_counter == 0b0011)
                    control_word = 0x2100;              //RI AO
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b0101:                                //----------LDI----------
                if(instr_counter == 0b0010)
                    control_word = 0x0A00;              //IO AI
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b0110:                                //----------JMP----------
                if(instr_counter == 0b0010)
                    control_word = 0x0802;              //IO J
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b0111:                                //----------JC----------
                if(instr_counter == 0b0010)
                    control_word = 0x0000;              //FI (update)
                else if(instr_counter == 0b0011)
                    control_word = 0x0801;              //IO J
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b1000:                                //----------JZ----------
                if(instr_counter == 0b0010)
                    control_word = 0x0000;              //
                else if(instr_counter == 0b0011)
                    control_word = 0x0801;              //IO J
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b1001:

            break;
            case 0b1010:

            break;
            case 0b1011:

            break;
            case 0b1100:

            break;
            case 0b1101:

            break;
            case 0b1110:                                //----------OUT----------
                if(instr_counter == 0b0010)
                    control_word = 0x0110;              //AO OI
                else
                    control_word = 0x0000;              //no other steps
            break;
            case 0b1111:                                //----------HLT----------
                if(instr_counter == 0b0010)
                    control_word = 0x8000;              //HLT
                else
                    control_word = 0x0000;              //no other steps
            break;



        }
        }

        return control_word;
    }
};//control module

void all_data_dump(){
    //std::cout<< "Data dump";
}//data dump

void halt(){
    running = false;
}//halt

int main(){
    ShowConsoleCursor(false);
    //std::cout <<"This is the 8-bit computer emulator"<<std::endl;
    counter instruction_counter(5);
    register_module reg_A;
    register_module reg_B;
    register_module reg_Inst;
    arithmetic_logic_unit ALU;
    output_module Display;
    clock_module clock1(100000);
    memory_module ram;
    counter program_counter(0);
    control_module controller;
//read input file, get memory contents

    std::ifstream myfile("input.txt");
    if(!myfile){
        std::cout <<"There's no input file" <<std::endl;
    }
    // int index = 0;
    while(!myfile.eof()){
        std::string temp;
        std::getline(myfile, temp, '\n');
        //std::cout<<temp<<std::endl;
        
        //std::cout<<temp.size()<<std::endl;
        for(int i=0; i<temp.size()/8; i++){
            std::string byte;
            for(int j=0; j<8; j++){
                byte += temp[(i*8)+j];
            }
            //std::cout<<byte<<std::endl;
            ram.ram[i]= stoi(byte,0,2);

        }
        // ram.ram[index] = stoi(temp, 0, 2);
        // std::cout<<ram.ram[index]<<std::endl;
        // index ++;
    }
    myfile.close();




    while(running){
        /*
        This while loop will run every "clock cycle"
        Values corresponding to each component of the control word:
        1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16
        HLT MI  RI  RO  IO  II  AI  AO  ΣO  SU  BI  OI  CE  CO  J   FI 
        Priority 0:
        - HLT SU
        Priority 1:
        - RO IO AO ΣO CO J
        Priority 2:
        - MI RI II AI BI OI FI CE
        */
        //std::cout<<"Bus " << bus << std::endl;//stop being weird
        controller.input(reg_Inst, instruction_counter);
        unsigned short controlword = controller.control_word_update();
        //std::cout<<"controlword: "<< std::hex << controlword <<std::endl;
        if(controlword & HLT){
            //std::cout<<"halt"<<std::endl;
            running = false;
            break;
        }
        if(controlword & SU){
            ALU.subtract();
            //std::cout<<"subtract"<<std::endl;
            }
        if(controlword & RO){
            ram.output();
            //std::cout<<"Ram Out"<<std::endl;
            }
        else if(controlword & IO){
            reg_Inst.output();
            bus = bus &0x0F;
            //std::cout<<"Instruction register out"<<std::endl;
            }
        else if(controlword & AO){
            reg_A.output();
            //std::cout<<"A out"<<std::endl;
            }
        else if(controlword & SUMO){
            //bus = reg_A.data + reg_B.data;
            ALU.output(reg_A, reg_B);
            //std::cout<<"ALU out"<<std::endl;
            }
        else if(controlword & CO){
            program_counter.output();
            //std::cout<<"program counter out"<<std::endl;
            }
        if(controlword & J){
            program_counter.current_count = bus &0x0F;
            //instruction_counter.current_count = 0;
        }
        if(controlword & MI){
            ram.memory_input();
            //std::cout<<"memory input"<<std::endl;
            }
        if(controlword & RI){
            ram.input();
            //std::cout<<"ram input"<<std::endl;
            }
        if(controlword & II){
            reg_Inst.input();
            //std::cout<<"instruction register input"<<std::endl;
            }
        if(controlword & AI){
            reg_A.input();
            //std::cout<<"A in"<<std::endl;
            }
        if(controlword & BI){
            reg_B.input();
            //std::cout<<"B in"<<std::endl;
            }
        if(controlword & OI){
            Display.input();
           // std::cout<<"Display in"<<std::endl;
            }
        if(controlword & FI){
            if(jumpcarry && (reg_Inst.data & 0xF0) == 0x70){
                program_counter.current_count = bus;
            }
            else if(ALU.jump_zero(reg_A, reg_B) && (reg_Inst.data & 0x80)!=0){
                program_counter.current_count = bus;
            }
            
        }
            //updates the flags register
        if(controlword & CE){
            program_counter.increment(); 
            //std::cout<<"increment program counter"<<std::endl;
            }
//the command prompt display stuff
        ClearScreen();
        std::cout<<std::endl;
        std::cout<<"                                8-Bit Computer Emulator"<<std::endl;
        std::cout<<std::endl;
        std::cout << "-------------------------------------------------------------------------------------------------------" <<std::endl;
        std::cout<<std::endl;
        std::cout << "               Clock: "<< std::bitset<4>(clock1.count)<<"            Bus: "<<std::bitset<8>(bus)<<"      Program Counter: "<<std::bitset<4>(program_counter.current_count) <<std::endl;
        std::cout << "       Memory Access: "<<std::bitset<4>(ram.memory_address)<<"                                Flags Register: "<<jumpcarry <<jumpzero <<std::endl;
        std::cout << "     Memory Contents: "<<std::bitset<8>(ram.ram[ram.memory_address])<<"                                A Register: "<<std::bitset<8>(reg_A.data) <<std::endl;
        std::cout << "Instruction Register: " << std::bitset<8>(reg_Inst.data)<<"                                       ALU: "<< std::bitset<8>(ALU.datadump(reg_A, reg_B))<<std::endl;
        std::cout << " Instruction Counter: " << std::bitset<4>(instruction_counter.current_count)<< "                                    B Register: "<< std::bitset<8>(reg_B.data)<<std::endl;
        std::cout << "        Control Word: " << std::bitset<16>(controlword)<< "                            Output: "<< std::setfill('0') << std::setw(3) << Display.data<<std::endl;
        std::cout << "-------------------------------------------------------------------------------------------------------" <<std::endl;


        ALU.jump_carry(reg_A, reg_B);
        ALU.jump_zero(reg_A, reg_B);
        instruction_counter.increment();
        clock1.clock_update();//for now, will just act as a sleep, but may be able to act as a step or halt.
        std::cout << std::endl;
    }
 do{
     std::cout<<std::endl;
     std::cout<<"The Program has been executed!"<<std::endl;
     std::cout<< "Press any key to exit...";
 } while (std::cin.get() != '\n');
return 0;
}